import pytest
import time

from src.human import Human, Status


def test_human_creation():
    """
    This tests the creation of a human
    object with specfic properties
    """
    init_location = (10, 10)
    init_velocity = (1, 1)
    init_status = Status.INFECTED
    init_ttr = 100
    human = Human(
        location=init_location,
        velocity=init_velocity,
        status=init_status,
        time_till_recovery=init_ttr,
    )
    assert (human.location == init_location).all()
    assert (human.velocity == init_velocity).all()
    assert human.status == init_status
    assert human.time_till_recovery == init_ttr


def test_human_recovery():
    """
    Tests if a human can recover
    """
    init_location = (10, 10)
    init_velocity = (0, 0)
    human = Human(init_location, init_velocity)

    human.infect(5)
    while human.is_infected():
        human.update(init_location, init_velocity, init_velocity)

    assert human.is_recovered()
