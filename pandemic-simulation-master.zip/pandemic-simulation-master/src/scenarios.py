import matplotlib.pyplot as plt
import matplotlib.animation as animation
import math
import time

from src.human import Status
import src.init as init
import src.simulation as sim


# global variables that will influence the simulation, including default values
world_limit = 100
human_radius = 5
time_step = 0.0001
infection_probability = 1
plot_refresh_rate = 50

# variables the simulation will work with
global_humans = []
inf = []
suc = []
rec = []
steps = []


def scenario1(plot=plt, show=False):
    # plot setup
    fig = plot.figure(figsize=(10,4))
    
    # for humans
    plot_humans = fig.add_subplot(1, 2, 1)
    plot_humans.axes.xaxis.set_visible(False)
    plot_humans.axes.yaxis.set_visible(False)

    # for stackplot
    plot_stack = fig.add_subplot(1, 2, 2)
    plot_stack.set_frame_on(False)
    plot_stack.axes.xaxis.set_visible(False)
    plot_stack.axes.yaxis.set_visible(False)

    # variables that influence the simulation
    world_limit = 100
    infection_radius = 5
    time_step = 0.0001
    plot_refresh_rate = 20

    # prob = float(input("Probability of infection: "))
    # number_of_humans = float(input("Number of humans: "))
    # temperature = float(input("Temperature: "))
    prob = 1
    number_of_humans = 50
    temperature = 10000

    # setting up the list of humans
    global_humans, energy = init.init_sys(
        temperature,
        prob,
        number_of_humans,
        infection_radius=infection_radius,
        world_limit=world_limit,
    )

    inf = []
    suc = []
    rec = []
    steps = []
    
    # animation of the movement of humans
    ani_humans = animation.FuncAnimation(
        fig,
        scenario1_animation,
        fargs=[global_humans, plot_humans, time_step,energy],
        interval=plot_refresh_rate,
    )

    # animation of the stackplot   
    ani_stack = animation.FuncAnimation(
        fig,
        stack_animation,
        fargs=[global_humans, plot_stack, time_step,inf, rec, suc, steps,number_of_humans],
        interval=plot_refresh_rate)
        
    if show:
        plot.show()
    return plot, ani_humans, ani_stack

def scenario1_animation(i, humans, subplot, time_step, energy):
    """updates human every timestep""" 
    new_energy = 0
    xs = []
    ys = []
    colors = []

    # set colors
    for h in humans:
        xs.append(float(h._x))
        ys.append(float(h._y))
        colors.append(h.color)
        
    subplot.clear()
    subplot.scatter(xs, ys, s=25, c=colors)
    subplot.set_ylim(0, 100)
    subplot.set_xlim(0, 100)
    global_humans = sim.calculate_movement(humans, time_step, energy)
    
def stack_animation(i, humans, test, time_step, inf, rec, suc, steps,number_of_humans):
    """updates the stackplot every timestep"""
    step_counter = len(suc)
    steps.append(time_step*step_counter)
    suc_s = 0
    inf_s = 0
    rec_s = 0
    
    # counting the amount of different states
    for h in humans:
        if h.status == Status.SUCEPTIBLE:
            suc_s +=1
        if h.status == Status.INFECTED:
            inf_s +=1
        if h.status == Status.RECOVERED:
            rec_s +=1
    suc.append(suc_s)
    inf.append(inf_s)
    rec.append(rec_s)        
    test.clear()
    test.set_ylim(0,len(humans))
    test.stackplot(steps, inf, rec,suc, colors=['#df0000','#4a4a4a','#0000df'])
