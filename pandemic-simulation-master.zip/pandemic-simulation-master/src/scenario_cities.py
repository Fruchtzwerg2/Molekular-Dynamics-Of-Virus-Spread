import matplotlib.pyplot as plt
import matplotlib.animation as animation
import math
import time
import random
import numpy as np

from src.human import Status, Human
import src.init as init
import src.simulation as sim

# global variables that will influence the simulation, including default values
world_limit = 100
human_radius = 5
time_step = 0.001
infection_probability = 1
plot_refresh_rate = 50

# variables the simulation will work with
humans_city1 = []
humans_city2 = []
humans_city3 = []
inf = []
suc = []
rec = []
steps = []


def scenario1(plot=plt, show=False):
    # plot setup
    fig = plot.figure(figsize=(10,8))
    
    # city1
    plot_city1 = fig.add_subplot(2, 2, 1)
    plot_city1.axes.xaxis.set_visible(False)
    plot_city1.axes.yaxis.set_visible(False)

    #city2
    plot_city2 = fig.add_subplot(2, 2, 2)
    plot_city2.axes.xaxis.set_visible(False)
    plot_city2.axes.yaxis.set_visible(False)
    
    #city3
    plot_city3 = fig.add_subplot(2, 2, 3)
    plot_city3.axes.xaxis.set_visible(False)
    plot_city3.axes.yaxis.set_visible(False)
    
     # for stackplot 1
    plot_stack1 = fig.add_subplot(2, 2, 4)
    plot_stack1.set_frame_on(False)
    plot_stack1.axes.xaxis.set_visible(False)
    plot_stack1.axes.yaxis.set_visible(False)
    

    # variables that influence the simulation
    world_limit = 100
    infection_radius = 10
    time_step = 0.0001
    plot_refresh_rate = 20

    # prob = float(input("Probability of infection: "))
    # number_of_humans = float(input("Number of humans: "))
    # temperature = float(input("Temperature: "))
    prob = 1
    number_of_humans = 15
    temperature = 10000

    humans_city1, energy1 = init.init_sys(
        temperature,
        prob,
        number_of_humans,
        infection_radius=infection_radius,
        world_limit=world_limit,
    )
    humans_city2, energy2 = init.init_sys(
        temperature,
        prob,
        number_of_humans,
        infection_radius=infection_radius,
        world_limit=world_limit,
    )
    humans_city3, energy3 = init.init_sys(
        temperature,
        prob,
        number_of_humans,
        infection_radius=infection_radius,
        world_limit=world_limit,
    )
        
    for h in humans_city2:
        h.status = Status.SUCEPTIBLE
    for h in humans_city3:
        h.status = Status.SUCEPTIBLE

    # setup for the animations in the plots
    # for city1
    ani_city1 = animation.FuncAnimation(
        fig,
        scenario1_animation,
        fargs=[humans_city1, humans_city2, humans_city3, plot_city1, time_step,energy1, steps],
        interval=plot_refresh_rate,
    )
    
    # for city2
    ani_city2 = animation.FuncAnimation(
        fig,
        scenario1_animation,
        fargs=[humans_city2, humans_city1, humans_city3, plot_city2, time_step,energy2, steps],
        interval=plot_refresh_rate,
    )
    
    # for city3
    ani_city3 = animation.FuncAnimation(
        fig,
        scenario1_animation,
        fargs=[humans_city3, humans_city2, humans_city1, plot_city3, time_step,energy3, steps],
        interval=plot_refresh_rate,
    )
    
    # for stackplot    
    ani_stack = animation.FuncAnimation(
        fig,
        stack_animation,
        fargs=[humans_city1, humans_city3, humans_city2, plot_stack1, time_step,inf, rec, suc, steps],
        interval=plot_refresh_rate)
    
    
    if show:
        plot.show()
    return plot, ani_city1, ani_city2, ani_city3, ani_stack


def scenario1_animation(i, humans, others1, others2, subplot, time_step, energy, steps):
    new_energy = 0
    xs = []
    ys = []
    colors = []

    for h in humans:
        xs.append(float(h._x))
        ys.append(float(h._y))
        colors.append(h.color)
        
    subplot.clear()
    subplot.scatter(xs, ys, s=25, c=colors)
    subplot.set_ylim(0, 100)
    subplot.set_xlim(0, 100)
    global_humans = sim.calculate_movement(humans, time_step, energy)
   

    #Particles moving from city to city
    if len(steps)%25 == False and len(steps)!= 0:
        random_number1 = random.randint(0,len(humans)-1)
        random_number2 = random.randint(0,len(humans)-1)
        while random_number1 == random_number2:
            random_number2 = random.randint(0,len(humans)-1)
        if random_number1 != random_number2:
            others1.append (humans[random_number1])
            others2.append (humans[random_number2])
            if random_number1 > random_number2:
                del humans[random_number1]
                del humans[random_number2]
            if random_number2 > random_number1:
                del humans[random_number2]
                del humans[random_number1]

    
    
    
def stack_animation(i, humans1, humans2, humans3, test, time_step, inf, rec, suc, steps):
    global_humans = humans1+humans2+humans3
    step_counter = len(suc)
    steps.append(time_step*step_counter)
    suc_s = 0
    inf_s = 0
    rec_s = 0
    for h in global_humans:
        if h.status == Status.SUCEPTIBLE:
            suc_s +=1
        if h.status == Status.INFECTED:
            inf_s +=1
        if h.status == Status.RECOVERED:
            rec_s +=1
    suc.append(suc_s)
    inf.append(inf_s)
    rec.append(rec_s)        
    test.clear()
    test.set_ylim(0,len(global_humans))
    test.stackplot(steps, inf, rec,suc, colors=['#df0000','#4a4a4a','#0000df'])


