import matplotlib.pyplot as plt
import matplotlib.animation as animation
import math
import time
import random
import numpy as np

from src.human import Status, Human
import src.init as init
import src.simulation as sim

# global variables that will influence the simulation, including default values
world_limit = 100
human_radius = 5
time_step = 0.001
infection_probability = 1
# percetnage as whole number times the calculation timestep
detection_probability = 5 * time_step
plot_refresh_rate = 50

# variables the simulation will work with
global_humans = []
quarantine_humans = []
inf = []
suc = []
rec = []
qua = []
steps = []

def scenario_quarantine(plot=plt, show=False):
    # plot setup
    fig = plot.figure(figsize=(10,4))
    
    # for humans
    plot_humans = fig.add_subplot(2, 2, 1)
    plot_humans.axes.xaxis.set_visible(False)
    plot_humans.axes.yaxis.set_visible(False)

    # for quarantine
    plot_quarantine = fig.add_subplot(2, 2, 2)
    plot_quarantine.set_frame_on(False)
    plot_quarantine.axes.xaxis.set_visible(False)
    plot_quarantine.axes.yaxis.set_visible(False)

    # for stackplot
    plot_stack = fig.add_subplot(2, 2, 3)
    plot_stack.set_frame_on(False)
    plot_stack.axes.xaxis.set_visible(False)
    plot_stack.axes.yaxis.set_visible(False)

    # variables that influence the simulation
    world_limit = 100
    infection_radius = 5
    time_step = 0.0001
    plot_refresh_rate = 20

    # prob = float(input("Probability of infection: "))
    # number_of_humans = float(input("Number of humans: "))
    # temperature = float(input("Temperature: "))
    prob = 1
    number_of_humans = 50
    temperature = 10000

    # setting up the list of humans
    global_humans, energy = init.init_sys(
        temperature,
        prob,
        number_of_humans,
        infection_radius=infection_radius,
        world_limit=world_limit,
    )

    inf = []
    suc = []
    rec = []
    steps = []
    
    # animation of the movement of humans
    ani_humans = animation.FuncAnimation(
        fig,
        scenario_basic_animation,
        fargs=[global_humans, quarantine_humans, plot_humans, time_step,energy],
        interval=plot_refresh_rate,
    )

    # animation for quarantine number
    ani_quarantine = animation.FuncAnimation(
      fig,
      quarantine_animation,
      fargs=[global_humans, quarantine_humans, plot_quarantine],
      interval=plot_refresh_rate
    )

    # animation of the stackplot   
    ani_stack = animation.FuncAnimation(
        fig,
        stack_animation_quarantine,
        fargs=[global_humans, quarantine_humans, plot_stack, time_step,inf, rec, suc, steps,number_of_humans],
        interval=plot_refresh_rate)
        
    if show:
        plot.show()
    return plot, ani_humans, ani_stack

def scenario_basic_animation(i, humans, quarantined, subplot, time_step, energy):
    """updates human every timestep""" 
    new_energy = 0
    xs = []
    ys = []
    colors = []

    # set colors and x and y values for world
    for h in humans:
        xs.append(float(h._x))
        ys.append(float(h._y))
        colors.append(h.color)
    
    subplot.clear()
    subplot.scatter(xs, ys, s=25, c=colors)
    subplot.set_ylim(0, 100)
    subplot.set_xlim(0, 100)
    global_humans = sim.calculate_movement(humans, time_step, energy)

def quarantine_animation(i, humans, quarantined, plot):
    for h in humans:
        if h.is_infected() and np.random.rand() < detection_probability:
            humans.remove(h)
            quarantined.append(h)
    
    for q in quarantined:
      # update only the recovery for people in quarantine
        q.update(q.location, q.velocity)
        if q.is_recovered():
            quarantined.remove(q)
            humans.append(q)
    
    global_humans = humans
    quarantine_humans = quarantined

    plot.clear()
    plot.text(0, 0.5, "Quarantined: " + str(len(quarantined)), size=20, bbox=dict(boxstyle="square", ec=(0.9, 0.68, 0.12), fc=(1., 0.78, 0.22)))
    
def stack_animation_quarantine(i, humans, quarantined, test, time_step, inf, rec, suc, steps,number_of_humans):
    """updates the stackplot every timestep"""
    step_counter = len(suc)
    steps.append(time_step*step_counter)
    suc_s = 0
    inf_s = 0
    rec_s = 0
    
    # counting the amount of different states
    for h in humans:
        if h.status == Status.SUCEPTIBLE:
            suc_s +=1
        if h.status == Status.INFECTED:
            inf_s +=1
        if h.status == Status.RECOVERED:
            rec_s +=1
    suc.append(suc_s)
    inf.append(inf_s)
    qua.append(len(quarantined))
    rec.append(rec_s)        
    test.clear()
    test.set_ylim(0,len(humans))
    test.stackplot(steps, inf, qua, rec,suc, colors=['#df0000','#ffc637','#4a4a4a','#0000df'])
