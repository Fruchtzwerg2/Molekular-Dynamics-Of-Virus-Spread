import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
import math
import time
import random 

from src.human import Human
from src.human import Status
import src.init as init
import src.simulation as sim

# variables the simulation will work with

global_humans = []

steps = []

inf = []
suc = []
rec = []

inf_mask = []
suc_mask = []
rec_mask = []

inf_vulnerable = []
suc_vulnerable = []
rec_vulnerable = []


def scenario_mask_vulnerable(plot=plt, show=False):
    # plot setup
    fig = plot.figure(figsize=(10,4))
    
    # for healthy and vulnerable humans
    plot_humans = fig.add_subplot(1, 2, 1)
    plot_humans.axes.xaxis.set_visible(False)
    plot_humans.axes.yaxis.set_visible(False)

    # for stackplot
    plot_stack = fig.add_subplot(1, 2, 2)
    plot_stack.set_frame_on(False)
    plot_stack.axes.xaxis.set_visible(False)
    plot_stack.axes.yaxis.set_visible(False)

    # variables that influence the simulation
    world_limit = 100
    time_step = 0.0001
    plot_refresh_rate = 20

    # ask_for_input()
    # ask_for_more_input()

    # With these variables, you get a nice simulation.
    prob = 0.4
    number_of_humans = 60
    temperature = 10000
    
    number_vulnerable_humans = 20
    number_humans_with_mask = 20
    infection_radius = 4
    mask_radius = 2
    mask_prob = 0.2
    vulnerable_radius = 10
    vulnerable_prob = 0.9
    
    # setting up the list of humans
    global_humans, energy = init.init_sys(
        temperature,
        prob,
        number_of_humans,
        infection_radius=infection_radius,
        world_limit=world_limit,
    )
    
    global_humans = init.make_vulnerable(global_humans, number_of_humans, number_vulnerable_humans, infection_radius, vulnerable_prob, vulnerable_radius)
    global_humans = init.wear_mask(global_humans, number_of_humans, number_humans_with_mask, infection_radius, mask_prob, mask_radius)
    
    inf = []
    suc = []
    rec = []
    
    inf_mask = []
    suc_mask = []
    rec_mask = []

    inf_vulnerable = []
    suc_vulnerable = []
    rec_vulnerable = []
     
    steps = []
    
    # animation of the movement of humans
    ani_humans = animation.FuncAnimation(
        fig,
        scenario_mask_vulnerable_animation,
        fargs=[global_humans, plot_humans, time_step, energy],
        interval=plot_refresh_rate,
    )

    # animation of the stackplot   
    ani_stack = animation.FuncAnimation(
        fig,
        stack_animation,
        fargs=[
            global_humans, 
            plot_stack, 
            time_step, 
            inf_vulnerable, inf, inf_mask,
            rec_vulnerable, rec, rec_mask, 
            suc_vulnerable, suc, suc_mask, 
            steps, 
            number_of_humans,
            infection_radius,
            mask_radius,
            vulnerable_radius],
        interval=plot_refresh_rate)
        
    if show:
        plot.show()
    return plot, ani_humans, ani_stack

def scenario_mask_vulnerable_animation(i, humans, subplot, time_step, energy):
    """updates human every timestep""" 
    new_energy = 0
    xs = []
    ys = []
    colors = []

    # set colors
    for h in humans:
        xs.append(float(h._x))
        ys.append(float(h._y))
        colors.append(h.color)
        
    subplot.clear()
    subplot.scatter(xs, ys, s=25, c=colors)
    subplot.set_ylim(0, 100)
    subplot.set_xlim(0, 100)
    global_humans = sim.calculate_movement(humans, time_step, energy)
    
def stack_animation_vulnerable(
    i, 
    humans, 
    test, 
    time_step, 
    inf_vulnerable, inf, inf_mask,
    rec_vulnerable, rec, rec_mask, 
    suc_vulnerable, suc, suc_mask,
    steps, 
    number_of_humans,
    infection_radius,
    mask_radius,
    vulnerable_radius):
    
    #updates the stackplot every timestep
    step_counter = len(suc)
    steps.append(time_step*step_counter)
    suc_s = 0
    inf_s = 0
    rec_s = 0
    
    suc_mask_s = 0
    inf_mask_s = 0
    rec_mask_s = 0
    
    suc_vulnerable_s = 0
    inf_vulnerable_s = 0
    rec_vulnerable_s = 0
    
    # counting the amount of different states
    for h in humans:
        if h.infection_radius == infection_radius:
            if h.status == Status.SUCEPTIBLE:
                suc_s +=1
            if h.status == Status.INFECTED:
                inf_s +=1
            if h.status == Status.RECOVERED:
                rec_s +=1
        elif h.infection_radius == mask_radius:
            if h.status == Status.SUCEPTIBLE:
                suc_mask_s +=1
            if h.status == Status.INFECTED:
                inf_mask_s +=1
            if h.status == Status.RECOVERED:
                rec_mask_s +=1
        elif h.infection_radius == vulnerable_radius:
            if h.status == Status.SUCEPTIBLE:
                suc_vulnerable_s +=1
            if h.status == Status.INFECTED:
                inf_vulnerable_s +=1
            if h.status == Status.RECOVERED:
                rec_vulnerable_s +=1
            
    suc.append(suc_s)
    inf.append(inf_s)
    rec.append(rec_s)

    suc_mask.append(suc_mask_s)
    inf_mask.append(inf_mask_s)
    rec_mask.append(rec_mask_s)
    
    suc_vulnerable.append(suc_vulnerable_s)
    inf_vulnerable.append(inf_vulnerable_s)
    rec_vulnerable.append(rec_vulnerable_s)
    
    test.clear()
    test.set_ylim(0,len(humans))
    
    test.stackplot(
        steps, 
        inf_vulnerable, inf, inf_mask,
        rec_vulnerable, rec, rec_mask, 
        suc_vulnerable, suc, suc_mask, 
        colors=[
            '#9c0000', '#df0000', '#eb6666',
            '#3b3b3b', '#4a4a4a', '#6e6e6e',
            '#00009c', '#0000df', '#6666eb'
            ])
    
    
def ask_for_more_input(number_of_humans):
    """
    Asks for more specific input for the simulation that contains vulnerable humans
    and humans that are wearing a face mask. Checks if the user input is correct.
    
    Returns:
        number_vulnerable_humans (int): number of humans that belong to the vulnerable group
        number_humans_with_mask (int): number of humans that are wearing a face mask
    """
    # input for number_vulnerable_humans
    while True:
        try:
            number_vulnerable_humans = int(input("Number of vulnerable humans: "))
            if number_vulnerable_humans >= 0 and number_vulnerable_humans <= number_of_humans:
                break
            else:
                raise ValueError
        except ValueError:
            print(f"Please enter an integer between 0 and {number_of_humans}.")
            
    # input for number_humans_with_mask
    while True:
        try:
            number_humans_with_mask = int(input("Number of humans that are wearing a face mask: "))
            difference = number_of_humans - number_vulnerable_humans
            if number_humans_with_mask >= 0 and number_humans_with_mask <= difference:
                break
            else:
                raise ValueError
        except ValueError:
            print(f"Please enter an interger between 0 and {difference}.")
            
    return number_vulnerable_humans, number_humans_with_mask

